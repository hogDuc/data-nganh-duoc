import requests
from bs4 import BeautifulSoup
import pandas as pd
from datetime import datetime
import os
import sys
import re
from urllib.parse import urljoin
import urllib3

curr_path = os.path.dirname(os.path.abspath(__file__))
parent_path = curr_path.split("src")[0]
sys.path.append(parent_path)    
from src.utils.configs import DATA_RAW_PATH  # noqa: E402
from src.utils.helper_ingest import safe_get  # noqa: E402
from src.utils.logs import get_logger  # noqa: E402
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
logger = get_logger()

BASE_URL = "https://dav.gov.vn/"


def _choose_mapping(links):
    """
    Mapping 2 file:
        - File ngắn tên hơn → gmp
        - File dài hơn → gmp_baobi
    """
    dict_ = {}
    if links:
        if len(links) == 2:
            a, b = links
            return {
                "gmp": a if len(a) < len(b) else b,
                "gmp_baobi": b if len(a) < len(b) else a,
            }
        elif len(links) == 1:
            a = links[0]
            if "bao" in a.lower() or "baobi" in a.lower() or "GMP%20bao%20b%C3%AC%20" in a.lower():
                return {"gmp_baobi": a}
            else:
                return {"gmp": a}
        else:
            print(len(links))
            print(links)
            for a in links[:2]:
                if "bao" in a.lower() or "baobi" in a.lower() or "gmp%20bb%20" in a.lower() or "gmp%20bao%20b%C3%AC%20" in a.lower():
                    dict_.update({"gmp_baobi": a})
                else:
                    dict_.update({"gmp": a})
                print(dict_)
            return dict_
    else:
        print('Not found link excel')


def extract_date(soup):
    """Tìm ngày cập nhật trong thẻ h1."""
    for h1 in soup.find_all("h1"):
        if "Cập nhật tới ngày" in h1.text:
            match = re.search(r"(\d{1,2}/\d{1,2}/\d{4})", h1.text)
            match2 = re.search(r"(\d{1,2}.\d{1,2}.\d{4})", h1.text)
            
            if match:
                return datetime.strptime(match.group(1), "%d/%m/%Y").strftime("%Y-%m-%d")
            if match2:
                return datetime.strptime(match2.group(1), "%d.%m.%Y").strftime("%Y-%m-%d")
    return None


def save_file(
    session,
    link,
    timeout: int = 60,
    verify: bool = False,
    save_path: str = DATA_RAW_PATH,
):
    res = safe_get(session, link, timeout, verify)
    soup = BeautifulSoup(res.text, "html.parser")
    date_obj = extract_date(soup)
    if not date_obj:
        date_obj = datetime.today().strftime("%Y-%m-%d")
        print(f"Not found date, choose defaul: {date_obj}")

    links_file = [urljoin(BASE_URL, a["href"])
                  for a in soup.find_all("a", href=True)
                  if ".xlsx" in a["href"]]
    if not links_file:
        return
    dic_map = _choose_mapping(links_file)

    for name, link in dic_map.items():
        response = safe_get(session, link, timeout, verify)
        file_path = f"{save_path}/gmp/{name}_{date_obj}.xlsx"
        with open(file_path, "wb") as f:
            f.write(response.content)
        print(f"File đã tải về: {file_path}")


def get_all_link(session, timeout: int = 60, verify: bool = False):
    urls = "https://dav.gov.vn/danh-sach-cssx-duoc-cap-gmp-cua-dav-cn92-page{page}.html"
    all_links = []
    for i in range(1, 8):
        r = safe_get(
            session,
            urls.format(page=i),
            timeout,
            verify,
        )
        soup = BeautifulSoup(r.text, "html.parser")
        links = [
            a["href"]
            for a in soup.find_all("a", href=True)
            if "danh-sach-cac-cssx" in a["href"]
        ]
        # print(f"Link in page: {i}", links)
        all_links.extend(links)
    return all_links


def ingest_gmp_hist():
    session = requests.Session()

    all_links = get_all_link(session)
    for link in all_links:
        save_file(session=session, link=link)


def ingest_gmp(timeout: int = 60, verify: bool = False, save_path: str = DATA_RAW_PATH):
    logger.info("_________________Crawl GMP_________________")
    session = requests.Session()


    r = safe_get(
        session,
        "https://dav.gov.vn/danh-sach-cssx-duoc-cap-gmp-cua-dav-cn92.html",
        timeout,
        verify,
    )
    soup = BeautifulSoup(r.text, "html.parser")
    links = [
        a["href"]
        for a in soup.find_all("a", href=True)
        if "danh-sach-cac-cssx" in a["href"]
    ]
    link_newest = links[0]
    save_file(session, link_newest)
    logger.info("_________________DONE Crawl GMP_________________")
    # res = safe_get(session, link_newest, timeout, verify)
    # soup = BeautifulSoup(res.text, "html.parser")
    # for h1 in soup.find_all("h1"):
    #     if "Cập nhật tới ngày" in h1.text:
    #         match = re.search(r"(\d{1,2}/\d{1,2}/\d{4})", h1.text)
    #         if match:
    #             date_report = match.group(1)
    #             date_obj = datetime.strptime(date_report, "%d/%m/%Y").strftime(
    #                 "%Y-%m-%d"
    #             )

    # links_file = [
    #     "https://dav.gov.vn/" + a["href"]
    #     for a in soup.find_all("a", href=True)
    #     if ".xlsx" in a["href"]
    # ]

    # dic_map = _choose_mapping(links_file)

    # for name, link in dic_map.items():
    #     response = safe_get(session, link, timeout, verify)
    #     file_path = f"{save_path}/gmp/{name}_{date_obj}.xlsx"
    #     with open(file_path, "wb") as f:
    #         f.write(response.content)
    #     print(f"File đã tải về: {file_path}")


if __name__ == "__main__":
    # ingest_gmp_hist()
    ingest_gmp()
