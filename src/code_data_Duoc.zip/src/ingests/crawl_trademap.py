from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait, Select
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager
import time
import sys
import os
import random

# --- Import config ---
curr_path = os.path.dirname(os.path.abspath(__file__))
parent_path = curr_path.split("src")[0]
sys.path.append(parent_path)
from src.utils.configs import (  # noqa: E402
    DATA_RAW_PATH,
    DRIVER_PATH,
    TRADEMAP_USERNAME,
    TRADEMAP_PASSWORD,
    HEADLESS
)
from src.utils.logs import get_logger  # noqa: E402
from src.utils.helper_ingest import setup_driver  # noqa: E402

logger = get_logger()
delay = random.randint(8, 20)


# ======================================================
#                  LOGIN FUNCTION
# ======================================================
def trademap_login(driver, username, password):
    """
    Login vào TradeMap với xử lý lỗi tốt hơn
    """
    try:
        wait = WebDriverWait(driver, 100)
        print("==> Tìm nút login")
        login_button = wait.until(
            EC.element_to_be_clickable((By.ID, "ctl00_MenuControl_marmenu_login"))
        )
        login_button.click()
        print("==> Đã click login")

        wait.until(EC.url_contains("Login"))
        print("==> Đã chuyển đến trang login")
        time.sleep(3)

        # Tìm và điền username
        print("==> Tìm trường username...")
        user_input = wait.until(EC.presence_of_element_located((By.ID, "Email")))
        user_input.clear()
        user_input.send_keys(username)
        print(f"==> Đã nhập username: {username}")

        # Tìm và điền password
        print("==> Tìm trường password...")
        pass_input = wait.until(EC.presence_of_element_located((By.ID, "Password")))
        pass_input.clear()
        pass_input.send_keys(password)
        print("==> Đã nhập password")

        # Tìm nút login bằng nhiều cách
        print("==> Tìm nút login...")
        login_btn = None

        # Thử 1: Tìm theo CSS selector
        try:
            login_btn = driver.find_element(
                By.CSS_SELECTOR,
                "body > main > div > div > section > form > div > div > button",
            )
            print("==> Tìm thấy nút login bằng CSS selector")
        except:
            pass

        if not login_btn:
            raise Exception("Không tìm thấy nút login")

        # Click nút login
        print("==> Click nút login...")
        login_btn.submit()

        # Chờ login thành công
        print("==> Đợi login hoàn tất...")
        time.sleep(5)
        return True

    except Exception as e:
        print(f"Login failed with error: {e}")
        # In ra HTML để debug
        try:
            print("\n=== Page Source Preview ===")
            print(driver.page_source[:1000])
        except:
            pass
        return False


# ======================================================
#                  CHỌN DROPDOWN FUNCTION
# ======================================================
def select_dropdowns_general(driver):
    wait = WebDriverWait(driver, 20)
    # Chọn by_country
    select_element_country = wait.until(
        EC.presence_of_element_located(
            (By.ID, "ctl00_NavigationControl_DropDownList_OutputOption")
        )
    )
    select_country = Select(select_element_country)
    select_country.select_by_value("ByCountry")
    print("Choose By Country successfully")
    time.sleep(3)
    # Chọn MirrorDirect
    select_element_direct = wait.until(
        EC.presence_of_element_located(
            (By.ID, "ctl00_NavigationControl_DropDownList_MirrorDirect")
        )
    )
    select_type = Select(select_element_direct)
    select_type.select_by_value("M")
    print("Choose MirrorDirect successfully")
    time.sleep(10)


def select_dropdowns(driver, item: str = "prices"):
    """Chọn indicator"""
    # --- Chọn loại giá trị (Values / Unit values / v.v.) ---
    for _ in range(5):
        try:
            select_element = driver.find_element(
                By.ID, "ctl00_NavigationControl_DropDownList_TS_Indicator"
            )
            select_indicator = Select(select_element)
            if item == "prices":
                select_indicator.select_by_value("UV")  # Unit values
                print("Choose Indicator = Unit values successfully")
            elif item == "quantities":
                select_indicator.select_by_value("Q")  # Unit values
                print("Choose Indicator = Quantities successfully")
            break
        except Exception as e:
            print("Option chưa sẵn sàng, đợi 2s rồi thử lại...", e)
            time.sleep(2)
    else:
        raise Exception(f"Không tìm thấy option {item} sau 5 lần thử")


# ======================================================
#                  DOWNLOAD FUNCTION
# ======================================================
def wait_and_rename(download_dir, prefix="trademap", timeout=20):
    """
    Chờ file tải xong và đổi tên theo ngày hiện tại.
    Tên file: {prefix}_YYYY-MM-DD.xlsx
    """
    import glob
    import shutil
    import datetime

    start_time = time.time()
    while time.time() - start_time < timeout:
        # Kiểm tra còn file .crdownload
        if not glob.glob(os.path.join(download_dir, "*.tmp")):
            # Lấy file Excel mới nhất
            excel_files = glob.glob(os.path.join(download_dir, "*.xls*"))
            if excel_files:
                latest_file = max(excel_files, key=os.path.getctime)
                today_str = datetime.datetime.today().strftime("%Y-%m-%d")
                new_name = f"{prefix}_{today_str}.xlsx"
                new_path = os.path.join(download_dir, new_name)

                # Nếu file đã tồn tại, thêm số thứ tự
                count = 1
                while os.path.exists(new_path):
                    new_name = f"{prefix}_{today_str}_{count}.xlsx"
                    new_path = os.path.join(download_dir, new_name)
                    count += 1

                shutil.move(latest_file, new_path)
                print(f"File save: {new_name}")
                return new_path
        time.sleep(1)
    raise TimeoutError("Not found file after 60s")


def download_file(driver, time_frame, download_dir, item):
    """Tải file Excel theo khung thời gian"""
    try:
        wait = WebDriverWait(driver, 20)
        button_excel = wait.until(
            EC.element_to_be_clickable(
                (
                    By.ID,
                    "ctl00_PageContent_GridViewPanelControl_ImageButton_ExportExcel",
                )
            )
        )
        button_excel.click()
        print(f"Download file excel: {time_frame} ...")
        time.sleep(15)  # chờ file tải xong
        wait_and_rename(download_dir, prefix=f"trademap_{item}_{time_frame}")
    except Exception as e:
        print(f"Error download file {time_frame}: {e}")


def download_item(driver, download_dir, item="prices", time_series="all"):
    select_dropdowns(driver, item)
    # --- Chọn khung thời gian ---
    wait = WebDriverWait(driver, 30)
    map_time = {"yearly": 'TSY', "quarterly": "TSQ", "monthly": "TSM"}
    if time_series == "all":
        # download_file(driver, "yearly", download_dir, item)

        for key, value in map_time.items():
            try:
                select_element_time = wait.until(
                    EC.element_to_be_clickable(
                        (By.ID, "ctl00_NavigationControl_DropDownList_OutputType")
                    )
                )
                select_time = Select(select_element_time)
                print(f"Chossing {key}")
                select_time.select_by_value(value)
                time.sleep(delay)
                download_file(driver, key, download_dir, item)
            except Exception as e:
                print(f"Error choosing {key}: {e}")
    # elif time_series == "yearly":
    #     download_file(driver, "yearly", download_dir, item)
    elif time_series in map_time.keys():
        select_element_time = wait.until(
            EC.element_to_be_clickable(
                (By.ID, "ctl00_NavigationControl_DropDownList_OutputType")
            )
        )
        select_time = Select(select_element_time)
        try:
            print(f"Chossing {map_time[time_series]}")

            select_time.select_by_value(map_time[time_series])
            time.sleep(3)
            download_file(driver, map_time[time_series], download_dir, item)
        except Exception as e:
            print(f"Error choosing {map_time[time_series]}: {e}")


# ======================================================
#                  MAIN SCRIPT
# ======================================================
def ingest_price_trademap(time_series: str = "all"):
    logger.info("______________Ingest Trademap_______________")
    url_login = "https://legacy.trademap.org/Country_SelProductCountry_TS.aspx?nvpm=1%7c704%7c%7c%7c%7c030431%7c%7c%7c6%7c1%7c2%7c2%7c2%7c1%7c2%7c1%7c1%7c1"
    url_2941 = "https://legacy.trademap.org/Country_SelCountry_MQ_TS.aspx?nvpm=1%7c704%7c%7c%7c%7c2941%7c%7c%7c4%7c1%7c2%7c1%7c2%7c3%7c2%7c2%7c1%7c1"

    add_headers = "user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36"
    # download_dir = os.path.join(DATA_RAW_PATH, f"trademap_{time_series}")
    download_dir = os.path.join(DATA_RAW_PATH, "trademap")

    driver = setup_driver(
        download_dir=download_dir,
        path_driver=DRIVER_PATH,
        headless=False,
        add_option=add_headers,
    )

    try:
        # Bước 1: Truy cập trang login
        print("\n[1] Truy cập trang login...")
        driver.get(url_login)
        time.sleep(delay)

        # Bước 2: Login
        print("\n[2] Đăng nhập...")
        login_success = trademap_login(driver, TRADEMAP_USERNAME, TRADEMAP_PASSWORD)

        if not login_success:
            print("\n DỪNG: Không thể login")
            return

        # Bước 3: Chuyển đến trang dữ liệu
        print("\n[3] Chuyển đến trang dữ liệu HS 2941...")
        driver.get(url_2941)
        time.sleep(delay)

        # Bước 4: Chọn dropdown và download
        print("\n[4] Chọn các tùy chọn chung và download...")

        select_dropdowns_general(driver)

        for item in ["prices", "quantities"]:
            download_item(
                driver=driver,
                download_dir=download_dir,
                item=item,
                time_series=time_series,
            )

    except Exception as e:
        print(f"\n Error: {e}")
        import traceback

        traceback.print_exc()

    finally:
        driver.quit()
        print("Đã đóng trình duyệt")
        logger.info("______________DONE Ingest Trademap_________________")


if __name__ == "__main__":
    ingest_price_trademap("all")
    # ingest_price_trademap("yearly")
    # ingest_price_trademap("monthly")
    # ingest_price_trademap("quarterly")
