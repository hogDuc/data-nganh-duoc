import pandas as pd
import numpy as np
import datetime as dt
import os
from datetime import datetime
import sys
import requests

from selenium import webdriver
import random
from time import sleep
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service

# from selenium.webdriver.support.ui import WebDriverWait
# from selenium.webdriver.support import expected_conditions as EC
# from selenium.webdriver.support.ui import Select
from selenium.webdriver.common.by import By
from webdriver_manager.chrome import ChromeDriverManager

# --- Import config ---
curr_path = os.path.dirname(os.path.abspath(__file__))
parent_path = curr_path.split("src")[0]
sys.path.append(parent_path)
from src.utils.configs import DATA_RAW_PATH, DRIVER_PATH  # noqa: E402
from src.utils.helper_ingest import setup_driver  # noqa: E402
from src.utils.logs import get_logger  # noqa: E402

logger = get_logger()

delay = random.randint(1, 5)


# ======================================================
#                  SETUP SELENIUM
# ======================================================
# def setup_driver(download_dir: str = None, headless=True, path_driver=None):
#     from pathlib import Path

#     chrome_options = Options()
#     if download_dir:
#         chrome_options.add_experimental_option(
#             "prefs",
#             {
#                 "download.default_directory": str(download_dir),
#                 "download.prompt_for_download": False,
#                 "download.directory_upgrade": True,
#                 "safebrowsing.enabled": False,
#                 "safebrowsing.disable_download_protection": True,
#                 "plugins.always_open_pdf_externally": True,  # Disabling PDF Viewer plugin
#             },
#         )

#     if headless:
#         chrome_options.add_argument("--headless=new")
#     chrome_options.add_argument("--no-sandbox")
#     chrome_options.add_argument("--disable-dev-shm-usage")
#     chrome_options.add_experimental_option("excludeSwitches", ["enable-logging"])
#     chrome_options.add_argument("--log-level=3")
#     chrome_options.add_argument(
#         "user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36"
#     )

#     if path_driver is not None:
#         # Laptop
#         service = Service(executable_path=str(Path(path_driver)))

#     else:
#         # PC
#         service = Service(ChromeDriverManager().install())
#     driver = webdriver.Chrome(service=service, options=chrome_options)
#     return driver


# ========== Update các link mới nhất - Chỉ tải trang 1 ===========
def get_link():
    import requests
    import json

    url = r"https://www.customs.gov.vn/bridge?url=/customs/api/GetTKHQInfo"
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36 Edg/141.0.0.0",
        "Accept": "application/json, text/javascript, */*; q=0.01",
        "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
        "Origin": "https://www.customs.gov.vn",
        "Referer": "https://www.customs.gov.vn/",
    }
    # Dữ liệu từ phần Form Data (chuỗi JSON)
    payload = {
        "skip": 40,
        "take": 20,
        "ky": "",
        "textSearch": "",
        "the_loai": "0",
        "thoigianCongBo": "",
        "typeName": "GetListSoLieu",
        "language": "TIENGVIET",
        "timeout": 300
    }

    # API dùng form-data nhưng chứa JSON → cần gửi như sau:
    response = requests.post(url, headers=headers, data=json.dumps(payload), timeout=(30,50), verify=False)
    
    # Add error handling for failed requests or empty responses
    logger.info(f"API Response Status: {response.status_code}, Text length: {len(response.text)}, First 200 chars: {response.text[:200]}")
    
    if response.status_code != 200:
        logger.error(f"API request failed with status code {response.status_code}, Response: {response.text[:500]}")
        raise Exception(f"API request failed: {response.status_code}")
    
    if not response.text:
        logger.error("API response is empty")
        raise Exception("API response is empty")
    
    try:
        data = json.loads(response.text)
        if "arr" not in data:
            logger.error(f"Response missing 'arr' key. Response: {response.text[:500]}")
            raise Exception("Response missing 'arr' key")
        
        df = pd.DataFrame(data["arr"])
    except json.JSONDecodeError as e:
        logger.error(f"Failed to parse JSON response: {e}. Response text: {response.text[:500]}")
        raise Exception(f"Invalid JSON response from API: {e}")
    
    df = df[
        [
            "TIEU_DE",
            "NGAY_CONG_BO",
            "FILE_CHINH_THUC",
            "FILE_SO_BO",
        ]
    ]
    df.columns = [
        "Noidung",
        "Thang",
        "Link_CT",
        "Link_SB",
    ]
    return df


def phanloai(string):
    if "nước/vùng lãnh thổ" in string:
        i = "XNK_QG"
    elif "khẩu hàng hóa tháng" in string:
        i = "XNK_thang"
    else:
        i = "Khác"
    return i


def _phanloai_link(df_link: pd.DataFrame, folder: str):
    df_class = df_link[df_link.Folder == folder].copy()
    df_class.reset_index(inplace=True)
    links = []
    for i in range(0, len(df_class["Thang"])):
        if df_class.at[i, "year"] >= datetime.today().year:
            link = df_class.at[i, "Link_SB"]
        else:
            if df_class.at[i, "Link_CT"] == df_class.at[i, "Link_CT"]:
                link = df_class.at[i, "Link_CT"]
            else:
                link = df_class.at[i, "Link_SB"]
        links.append(link)
    print("All links will be downloaded: ", links)
    return links


def has_downloaded(path_download, choose_month):
    import re

    links_old = os.listdir(path_download)
    month_downloads = []
    for name_file in links_old:
        i_month = re.findall(R"\d+", name_file)[1]
        i_year = re.findall(R"\d+", name_file)[0]
        month_ = datetime(int(i_year), int(i_month), 28).strftime("%m-%Y")
        month_downloads.append(month_)
    if choose_month in month_downloads:
        return True
    else:
        return False


def download(df_links, folder, headless=True):
    download_directory = rf"{DATA_RAW_PATH}/xnk/{folder}"
    # add_headers = "user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36"

    # driver = setup_driver(
    #     download_dir=download_directory,
    #     path_driver=DRIVER_PATH,
    #     headless=headless,
    #     add_option=add_headers,
    # )
    # for i in _phanloai_link(df_links, folder):
    #     try:
    #         driver.get(i)
    #         sleep(delay)
    #         print(f"Sucessfully {folder}- {i}")
    #     except Exception as e:
    #         print(f"Error get file {e}")
    # driver.quit()

    for i in _phanloai_link(df_links, folder):
        filename = i.split('/')[-1] 
        try:
            response = requests.get(i, timeout=30)
            if response.status_code == 200:
            
                # Check có phải PDF không
                content_type = response.headers.get('Content-Type', '')
                if 'pdf' not in content_type.lower():
                    print(f"WARNING - Not file pdf ({content_type})")
                save_path = os.path.join(download_directory, filename) 
                with open(save_path, 'wb') as f:  # 'wb' quan trọng!
                    f.write(response.content)
                
                    # Verify file
                    size = os.path.getsize(save_path)
                    if size > 0:
                        print(f"Sucessfully {folder}- {i}")
                    else:
                        print("File empty!")
            else:
                print(f"Error HTTP {response.status_code}")
                return False
        except Exception as e:
            print(f"Error get file {e}")


def ingest_pdf_xnk():
    # Crawl vào giữa tháng
    logger.info("__________Ingest pdf XNK____________")
    choose_month = datetime.today() - pd.DateOffset(days=38)
    choose_month = choose_month.strftime("%m-%Y")
    print("Crawl data of month: ", choose_month)
    df_link = get_link()

    sleep(5)
    if df_link.empty:
        print("Not crawl link")
    df_link = df_link[df_link.Thang == choose_month]
    df_link["Folder"] = df_link.Noidung.transform(lambda x: phanloai(x))
    df_link["year"] = df_link["Thang"].transform(lambda x: int(x[-4:]))
    print(df_link)
    #if not has_downloaded(DATA_RAW_PATH / "xnk" / "XNK_thang", choose_month):
    logger.info("Downloading....")
    download(df_link, "XNK_QG", headless=False)
    download(df_link, "XNK_thang", headless=False)
    logger.info("DONE download pdf XNK")
    return True
    # else:
    #     logger.info("File downloaded previously-> SKIP")
    #     return False


if __name__ == "__main__":
    ingest_pdf_xnk()
