import requests
from bs4 import BeautifulSoup
import pandas as pd
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait, Select
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager
import time
import sys
import os

curr_path = os.path.dirname(os.path.abspath(__file__))
parent_path = curr_path.split("src")[0]
sys.path.append(parent_path)
from src.utils.configs import DATA_RAW_PATH, DRIVER_PATH
from src.utils.helper_ingest import safe_get


# def ingest_kqtrungthau(
#     timeout: int = 20, verify: bool = False, save_path: str = DATA_RAW_PATH
# ):
#     url = "https://quanlythuocv1.vss.gov.vn/kqdt"
#     params = {
#         "congbotu": "01/01/2022",
#         "congboden": "21/10/2025",
#     }
#     headers = {
#         "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36 Edg/141.0.0.0",
#         "Referer": "https://quanlythuocvss.gov.vn/kqdt",
#     }
#     session = requests.Session()
#     r = safe_get(session, url, params=params, headers=headers, timeout=20)
#     html = r.text
#     soup = BeautifulSoup(html, "html.parser")
#     cols_name = [th.get_text(strip=True) for th in soup.select("table thead tr th")]
#     rows = soup.select("table tbody tr")
#     data = []
#     for tr in rows:
#         cols = [td.get_text(strip=True) for td in tr.find_all("td")]
#         if cols:
#             data.append(cols)
#     if data:
#         df = pd.DataFrame(data)
#         df.columns = cols_name
#         df.to_csv(DATA_RAW_PATH / "trungthau.csv")
#         print('Ingest thanh cong!')
#     else:
#         print('Error ingest')


# TODO: Crawl file tải excel, ko phải bảng -> Tải bảng tay -> BỎ FILE
# def setup_driver(download_dir=DATA_RAW_PATH, headless=True, path_driver=None):
#     from pathlib import Path

#     chrome_options = Options()
#     prefs = {
#         "download.default_directory": str(download_dir),
#         "download.prompt_for_download": False,
#         "download.directory_upgrade": True,
#         "safebrowsing.enabled": True,
#     }
#     chrome_options.add_experimental_option("prefs", prefs)

#     if headless:
#         chrome_options.add_argument("--headless=new")
#     chrome_options.add_argument("--no-sandbox")
#     chrome_options.add_argument("--disable-dev-shm-usage")
#     chrome_options.add_experimental_option("excludeSwitches", ["enable-logging"])
#     chrome_options.add_argument("--log-level=3")
#     chrome_options.add_argument(
#         "user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36"
#     )

#     if path_driver is not None:
#         # Laptop
#         service = Service(executable_path=Path(path_driver))

#     else:
#         # PC
#         service = Service(ChromeDriverManager().install())
#     driver = webdriver.Chrome(service=service, options=chrome_options)
#     return driver


# def ingest_kqtrungthau():
#     driver = setup_driver(path_driver=DRIVER_PATH, headless=True)
#     url = "https://quanlythuoc.vss.gov.vn/kqdt"
#     driver.get(url)
#     time.sleep(3)
#     wait = WebDriverWait(driver, 20)  # Click checkbox Tân dược với CSS selector cụ thể
#     tan_duoc_checkbox = wait.until(
#         EC.presence_of_element_located(
#             (
#                 By.CSS_SELECTOR,
#                 "#table-data > tbody > tr:nth-child(1) > td:nth-child(2) > input",
#             )
#         )
#     )

#     # Scroll đến checkbox
#     driver.execute_script(
#         "arguments[0].scrollIntoView({block: 'center'});", tan_duoc_checkbox
#     )
#     time.sleep(1)

#     # Đảm bảo checkbox clickable
#     wait.until(
#         EC.element_to_be_clickable(
#             (
#                 By.CSS_SELECTOR,
#                 "#table-data > tbody > tr:nth-child(1) > td:nth-child(2) > input",
#             )
#         )
#     )

#     # Click bằng JavaScript để chắc chắn
#     driver.execute_script("arguments[0].click();", tan_duoc_checkbox)
#     button_excel = wait.until(
#         EC.element_to_be_clickable(
#             (
#                 By.CSS_SELECTOR,
#                 "body > div.content-container > div.container > a.btn.btn-success.btn-sm.pull-right.btn-export",
#             )
#         )
#     )
#     button_excel.click()
#     time.sleep(5)
#     driver.quit()


# if __name__ == "__main__":
#     ingest_kqtrungthau()
