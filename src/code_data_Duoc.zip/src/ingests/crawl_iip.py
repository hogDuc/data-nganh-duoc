from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from webdriver_manager.chrome import ChromeDriverManager
from bs4 import BeautifulSoup
import os
import re
import time
import requests
import sys

curr_path = os.path.dirname(os.path.abspath(__file__))
parent_path = curr_path.split("src")[0]
sys.path.append(parent_path)
from src.utils.configs import DATA_RAW_PATH, DRIVER_PATH  # noqa: E402
from src.utils.logs import get_logger  # noqa: E402
from src.utils.helper_ingest import setup_driver, safe_get  # noqa: E402

logger = get_logger()


# ===========================
# HÀM LẤY LINK BÀI VIẾT ĐẦU TIÊN
# ===========================
def get_first_article_link(driver, start_url, base_url):
    url = f"{start_url}?paged=1"
    driver.get(url)
    time.sleep(2)
    soup = BeautifulSoup(driver.page_source, "html.parser")

    links = []

    # Tìm link kế tiếp sau mỗi <h3>
    for h3 in soup.select("h3"):
        a = h3.find_next("a", href=True)
        if a:
            href = a["href"].strip()
            if href.startswith("/"):
                href = base_url + href
            links.append(href)

    # Chỉ lấy bài đầu tiên
    if links:
        print(f"Chọn bài đầu tiên: {links[1]}")
        return [links[1]]


# ===========================
# HÀM TẢI FILE EXCEL ĐẦU TIÊN
# ===========================
def download_first_excel_from_post(driver, post_url, save_dir):
    driver.get(post_url)
    time.sleep(2)
    soup = BeautifulSoup(driver.page_source, "html.parser")

    # Lấy tiêu đề bài viết
    title_tag = soup.find("h1")
    title_text = title_tag.get_text(strip=True) if title_tag else ""

    # Bảng chuyển đổi tháng viết chữ → số
    month_map = {
        "một": "1",
        "giêng": "1",
        "hai": "2",
        "ba": "3",
        "tư": "4",
        "bốn": "4",
        "năm": "5",
        "sáu": "6",
        "bảy": "7",
        "tám": "8",
        "chín": "9",
        "mười": "10",
        "mười một": "11",
        "mười hai": "12",
    }

    # Tìm cụm "tháng ... năm ..."
    match = re.search(
        r"tháng\s+([A-Za-zÀ-ỹ\d\s]+?)\s+năm\s+(\d{4})", title_text, re.IGNORECASE
    )
    if match:
        month_text = match.group(1).strip().lower()
        year = match.group(2)

        # Nếu tháng là số (ví dụ "9" hoặc "12")
        if month_text.isdigit():
            month_num = month_text
        else:
            month_num = month_map.get(month_text, month_text)

        # Ghép chuỗi tháng-năm
        month_year = f"{year}{month_num.zfill(2)}"
    else:
        month_year = "khong_ro_thang_nam"

    # Lấy file Excel đầu tiên trong mục đính kèm
    li = soup.select_one("ul.file-attachment li a[href]")
    href = li["href"].strip()
    text = li.get_text(strip=True).lower()

    # Xử lý đường dẫn và tên file
    base_url = "https://www.nso.gov.vn"
    file_url = href if href.startswith("http") else base_url + href
    original_name = os.path.basename(file_url.split("?")[0])
    name, ext = os.path.splitext(original_name)
    name = re.split(r"[-_]", name)[0]  # chỉ giữ phần đầu
    file_name = f"{name}_{month_year}{ext}"
    save_path = os.path.join(save_dir, file_name)

    # Tải file
    res = requests.get(file_url, verify=False, timeout=30)
    with open(save_path, "wb") as f:
        f.write(res.content)

    # nếu file đã tồn tại thì in cảnh báo và không ghi đè
    if os.path.exists(save_path):
        print(f"File {save_path} đã tồn tại → Skip download.")
    else:
        print("Download successful!")


# ===========================
# CHẠY HÀM
# ===========================
def ingest_iip():
    logger.info("_______________Ingest IIP______________")
    base_url = "https://www.nso.gov.vn"
    start_url = f"{base_url}/iip-vi/"
    save_dir = rf"{DATA_RAW_PATH}/iip"

    # chrome_options = Options()
    # chrome_options.add_argument('--proxy-server=http://10.26.2.55:8080')
    # chrome_options.add_argument(
    #     "user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120 Safari/537.36")

    # chrome_options.add_argument("--disable-blink-features=AutomationControlled")
    # chrome_options.add_experimental_option("excludeSwitches", ["enable-automation"])
    # chrome_options.add_experimental_option('useAutomationExtension', False)
    
    # chrome_options.add_argument("--no-sandbox")
    # chrome_options.add_argument("--disable-gpu")
    # chrome_options.add_argument("--disable-dev-shm-usage")
    # chrome_options.add_experimental_option("excludeSwitches", ["enable-logging"])
    # chrome_options.add_argument("--log-level=3")

    # driver = webdriver.Chrome(service=Service(DRIVER_PATH), options=chrome_options)
    driver = setup_driver(download_dir=save_dir, headless=True, path_driver=DRIVER_PATH)

    link = get_first_article_link(driver=driver, start_url=start_url, base_url=base_url)
    download_first_excel_from_post(driver, link[0], save_dir)

    driver.quit()
    logger.info("_______________DONE Ingested IIP______________")


if __name__ == "__main__":
    ingest_iip()
