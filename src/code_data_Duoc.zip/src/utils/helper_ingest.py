import requests


def safe_get(
    session: requests.Session,
    url: str,
    timeout: int = 60,
    verify: bool = True,
    params: dict = None,
    headers: dict = None,
):
    resp = session.get(
        url, timeout=timeout, verify=verify, headers=headers, params=params
    )

    resp.raise_for_status()
    return resp


def setup_driver(download_dir, headless=True, path_driver=None, add_option: str = None):
    from selenium import webdriver
    from selenium.webdriver.chrome.service import Service
    from selenium.webdriver.chrome.options import Options
    from pathlib import Path
    import os

    chrome_options = Options()
    prefs = {
        "download.default_directory": str(download_dir),
        "download.prompt_for_download": False,
        "plugins.always_open_pdf_externally": True,
        "download.directory_upgrade": True,
        "safebrowsing.enabled": True,
        "safebrowsing.disable_download_protection": True,
    }

    chrome_options.add_experimental_option("prefs", prefs)

    if headless:
        chrome_options.add_argument("--headless=new")

    chrome_options.add_argument('--proxy-server=http://10.26.2.55:8080')
    chrome_options.add_argument(
        "user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120 Safari/537.36")

    chrome_options.add_argument("--window-size=1920,1080")
    chrome_options.add_argument("--lang=en-US")
    chrome_options.add_argument("--disable-blink-features=AutomationControlled")
    chrome_options.add_experimental_option("excludeSwitches", ["enable-automation"])
    chrome_options.add_experimental_option('useAutomationExtension', False)
    
    chrome_options.add_argument("--no-sandbox")
    chrome_options.add_argument("--disable-gpu")
    chrome_options.add_argument("--disable-dev-shm-usage")
    chrome_options.add_experimental_option("excludeSwitches", ["enable-logging"])
    chrome_options.add_argument("--log-level=3")
    if add_option:
        chrome_options.add_argument(add_option)
    try:
        if path_driver is not None:
            # Dùng path cụ thể
            service = Service(executable_path=str(Path(path_driver)))
        elif os.path.exists("/usr/local/bin/chromedriver"):
            # Docker: ChromeDriver đã được cài đặt sẵn
            service = Service(executable_path="/usr/local/bin/chromedriver")
        else:
            # Local: Dùng ChromeDriverManager
            from webdriver_manager.chrome import ChromeDriverManager

            service = Service(ChromeDriverManager().install())

        driver = webdriver.Chrome(service=service, options=chrome_options)
        return driver

    except Exception as e:
        print(f"Lỗi khởi tạo driver: {e}")
        # Fallback: thử không dùng service (image selenium/standalone-chrome)
        driver = webdriver.Chrome(options=chrome_options)
        return driver
