from pathlib import Path
from dotenv import load_dotenv
import os

BASE_PATH = Path(__file__).resolve().parents[2]
load_dotenv(dotenv_path=BASE_PATH / ".env")
TRADEMAP_USERNAME = os.getenv("trademap_username")
TRADEMAP_PASSWORD = os.getenv("trademap_password")

DATA_RAW_PATH = BASE_PATH / "data" / "raw"
DATA_TRANS_PATH = BASE_PATH / "data" / "transformed"
DATA_CHART_PATH = BASE_PATH / "data" / "chart"

# DRIVER_PATH = Path(
#     r"D:\OneDrive - fpts.com.vn\Desktop\HaPTN_FPA\chromedriver-win64\chromedriver.exe"
# )     # Chạy máy local
DRIVER_PATH = None  # CHạy DOCKER
if DRIVER_PATH:
    HEADLESS = False
else:
    HEADLESS = True
DATA_INPUT_BMI = rf"{BASE_PATH}/data/input/Dữ liệu BMI - Dược.xlsx"
DATA_INPUT_EURO = rf"{BASE_PATH}/data/input/Company shares.xls"
DATA_INPUT_IMPORT_QG = rf"{BASE_PATH}/data/input/import_quocgia.xlsx"
DATA_INPUT_IMPORT_MH = rf"{BASE_PATH}/data/input/import_mathang.xlsx"
