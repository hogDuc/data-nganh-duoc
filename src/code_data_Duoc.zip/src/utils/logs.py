import logging
import sys
import os


def get_logger(name: str = __name__, log_dir: str = "logs") -> logging.Logger:
    """
    Tạo logger chuẩn dùng cho toàn bộ project.

    Parameters
    ----------
    name : str
        Tên logger (thường là __name__ của module gọi).

    Returns
    -------
    logging.Logger
    """

    logger = logging.getLogger(name)
    if not logger.handlers:
        format = logging.Formatter(
            fmt="%(asctime)s - %(levelname)s - %(message)s", datefmt="%Y-%m-%d %H:%M:%S"
        )
        # --- 1. In ra console ---
        stream_handler = logging.StreamHandler(sys.stdout)
        stream_handler.setFormatter(format)
        logger.addHandler(stream_handler)

        # --- 2. Ghi ra file ---
        os.makedirs(log_dir, exist_ok=True)  # tạo thư mục logs nếu chưa có
        log_file = os.path.join(log_dir, "pipeline.log")

        file_handler = logging.FileHandler(log_file, encoding="utf-8")
        file_handler.setFormatter(format)
        logger.addHandler(file_handler)

        # --- 3. Mức log ---
        logger.setLevel(logging.INFO)
    return logger
