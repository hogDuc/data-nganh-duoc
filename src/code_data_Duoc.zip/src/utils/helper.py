import os
import pandas as pd
from typing import List
from pathlib import Path
from .logs import get_logger

logger = get_logger()


def get_all_files(
    folder_path: str, ext: str = ".xls", recursive: bool = False
) -> List[str]:
    """
    Lấy danh sách tất cả các file có phần mở rộng nhất định trong folder.

    Args:
        folder_path (str): Đường dẫn folder gốc.
        ext (str): Phần mở rộng file cần lọc (mặc định '.xls').
        recursive (bool): Nếu True, đệ quy vào các folder con.

    Returns:
        List[str]: Danh sách đường dẫn file đã sắp xếp.
    """
    ext = ext.lower()
    all_files = []

    if recursive:
        for root, dirs, files in os.walk(folder_path):
            for f in files:
                if f.lower().endswith(ext):
                    all_files.append(os.path.join(root, f))
    else:
        for f in os.listdir(folder_path):
            full_path = os.path.join(folder_path, f)
            if os.path.isfile(full_path) and f.lower().endswith(ext):
                all_files.append(full_path)
    print(f"Tìm thấy {len(all_files)} file có phần mở rộng '{ext}' trong {folder_path} (recursive={recursive}): {all_files}")

    return sorted(all_files)


def load_processed_log(log_path: str):
    """Đọc file log lưu danh sách file đã xử lý."""
    if os.path.exists(log_path):
        # log_path = Path(log_path).name
        df_log = pd.read_csv(log_path)
        processed = set(df_log["filename"].tolist())
    else:
        processed = set()
    print(f"Đã tải {len(processed)} file đã xử lý từ log: {processed}")
    return processed


def find_unprocessed_files(
    folder_path: str, log_path: str, ext: str = ".xls", recursive: bool = False
):
    """Tìm các file chưa xử lý trong folder
    recursive (bool): Nếu True, đệ quy vào các folder con để tìm.
    """
    all_files = get_all_files(folder_path, ext, recursive=recursive)
    processed = load_processed_log(log_path)
    # processed_files = {Path(f).name for f in processed_files}
    processed_files = [str(Path(folder_path) / Path(f)) for f in processed]
    unprocessed = sorted(list(set(all_files) - set(processed_files)))
    print(f"Tìm thấy {len(unprocessed)} file chưa xử lý trong {folder_path}: {unprocessed}")

    return unprocessed


def update_processed_log(log_path: str, new_files: list):
    """Ghi thêm danh sách file mới đã xử lý vào log CSV."""
    if not new_files:
        return
    if os.path.exists(log_path):
        df_log = pd.read_csv(log_path)
    else:
        df_log = pd.DataFrame(columns=["filename"])
    new_df = pd.DataFrame({"filename": new_files})
    df_log = pd.concat([df_log, new_df], ignore_index=True)
    df_log.drop_duplicates(subset=["filename"], inplace=True)
    df_log.to_csv(log_path, index=False)
    logger.info(f"Đã cập nhật log với {len(new_files)} file mới.")


def run_time(
    name_job,
    start: float,
    end: float,
):
    """
    Tính thời gian chạy giữa hai mốc thời gian (giây).

    Args:
        start (float): thời gian bắt đầu (giây, từ time.time()).
        end (float): thời gian kết thúc (giây, từ time.time()).

    Returns:
        tuple: (minutes, seconds)
    """
    logger = get_logger()
    elapsed = end - start
    minutes = int(elapsed // 60)
    seconds = int(elapsed % 60)
    print(f"Run time {name_job}: {minutes}m{seconds}s")
    logger.info(f"Run time {name_job}: {minutes}m{seconds}s")
