import pandas as pd
import os
import sys
from bs4 import BeautifulSoup
import re
import unicodedata
from pathlib import Path

curr_path = os.path.dirname(os.path.abspath(__file__))
parent_path = curr_path.split("src")[0]
sys.path.append(parent_path)
from src.utils.configs import DATA_RAW_PATH, DATA_TRANS_PATH, DATA_CHART_PATH  # noqa: E402
from src.utils.logs import get_logger  # noqa: E402
from src.utils.helper import update_processed_log, find_unprocessed_files  # noqa: E402, F401

logger = get_logger()

# def transform_trungthau():
#     df = pd.read_csv(rf"{DATA_RAW_PATH}/trungthau.csv", dtype=str)
#     df.drop(index=0, inplace=True)
#     df.drop(columns=df.columns[0], inplace=True)
#     #  Loại bỏ dấu chấm trong toàn bộ dataframe
#     df = df.replace(r"\.", "", regex=True)
#     df = df.rename(columns={"Ngày công bố quyết định trúng thầu": "date"})
#     df = df[~df['date'].str.contains('Tháng')]
#     df = df.melt(id_vars="date", var_name='type', value_name='quantity')
#     df['date'] = pd.to_datetime(df['date'], dayfirst=True)
#     df['quantity'] = pd.to_numeric(df['quantity'])
#     df.to_parquet(rf"{DATA_TRANS_PATH}/trungthau.parquet")
#     print("Transform successfully trungthau")
#     return df


# def _transform_source_old(file_path):
#     """Transform dữ liệu 2020-2021 từ nguồn cũ - đuôi xlsx"""
#     df = pd.read_excel(file_path, engine="openpyxl", header=1)
#     df = df[
#         [
#             "Tên cở sở sản xuất",
#             "Nước sản xuất",
#             "ĐVT",
#             "Số lượng",
#             "Đơn giá \n(VNĐ)",
#             "Thành tiền",
#             "Nhà thầu trúng thầu",
#             "Nhóm thuốc",
#             "Thời gian thực hiện",
#             "Ngày QĐ trúng thầu",
#         ]
#     ]
#     df.columns = [
#         "nhasx",
#         "nuocsx",
#         "donvitinh",
#         "soluong",
#         "gia",
#         "thanhtien",
#         "nhomthau",
#         "congbo",
#         "tungay_hd",
#         "denngay_hd",
#     ]
#     return df


# Chuẩn hóa unicode & xóa ký tự lạ
def normalize_unicode(text):
    if not isinstance(text, str):
        return ""
    text = unicodedata.normalize("NFC", text)  # gộp các ký tự tổ hợp
    text = text.replace("\xa0", " ").replace("\n", " ")
    text = re.sub(r"\s+", " ", text)  # gộp nhiều dấu cách
    text = text.strip()
    return text


# Sửa chính tả cho các từ đơn
def normalize_single_word(word):
    mapping = {
        "lo": "lọ",
        "lọ": "lọ",
        "ống": "ống",
        "ông": "ống",
        "ồng": "ống",
        "ổng": "ống",
        "óng": "ống",
        "gói": "gói",
        "goi": "gói",
        "tuýp": "tuýp",
        "tuýp": "tuýp",
        "tuyp": "tuýp",
        "tuyb": "tuýp",
        "tub": "tuýp",
        "tupe": "tuýp",
        "tup": "tuýp",
        "tube": "tuýp",
        "túp": "tuýp",
        "tuýp/\n tube": "tuýp",
        "tuýp/ \ntube": "tuýp",
        "tuýp/ tube": "tuýp",
        "tuýp/ ống": "tuýp",
        "tuýp/tube": "tuýp",
        "binh": "bình",
        "binh xịt": "bình xịt",
        "lít": "lít",
        "ml": "ml",
        "1/4 ọ": "1/4 lọ",
        "xy lanh": "xylanh",
        "bút tiêm": "bút tiêm",
        "búttiêm": "bút tiêm",
        "bơm tièm": "bơm tiêm",
        "bơm\n tiêm": "bơm tiêm",
        "mci": "mcg",
        "viờn": "viên",
        "viên (đóng trong vĩ)": "viên (đóng vỉ)",
        "viêb": "viên",
        "ui": "túi",
        # thêm dần theo dữ liệu thực tế
    }
    w = normalize_unicode(word.lower())
    return mapping.get(w, w)


#  Hàm chuẩn hóa toàn cột unit
def clean_unit(text):
    if not isinstance(text, str):
        return ""
    x = normalize_unicode(text.lower())

    # Xử lý dấu phân cách (/, , ;)
    x = re.sub(r"\s*/\s*", "/", x)
    x = re.sub(r"[;,]", "/", x)
    x = re.sub(r"\s+", " ", x)

    # Nếu chỉ có 1 từ => chuẩn hóa chính tả
    if "/" not in x and " " not in x:
        return normalize_single_word(x)

    # Nếu có 2 tiếng trở lên => chuẩn hóa dấu cách và từ đơn trong đó
    parts = re.split(r"(?<!\d)/(?!\d)", x)
    cleaned = [normalize_single_word(p.strip()) for p in parts if p.strip()]
    return "/".join(cleaned)


# def normalize_company_name(name):
#     import re

#     if not isinstance(name, str):
#         return ""
#     name = name.lower()  # Chuyển về chữ thường
#     name = re.sub(r"[-–—,/]", " ", name)  # Xóa dấu gạch, dấu chấm
#     name = re.sub(r"\s+", " ", name).strip()  # Xóa khoảng trắng thừa

#     replacements = {
#         "cty": "công ty",
#         "co phan": "cổ phần",
#         "chi nhanh": "chi nhánh",
#         "nha may": "nhà máy",
#         "cp": "cổ phần",
#     }
#     for k, v in replacements.items():
#         name = name.replace(k, v)
#     return name


def normalize_nhomthau(value):
    # Chuyển về string và loại bỏ khoảng trắng thừa
    value = str(value).strip().upper()
    # Tìm pattern N + số từ 1-5
    match = re.search(r"N\s*([1-5])", value)
    if match:
        return f"N{match.group(1)}"
    # Tìm pattern "NHÓM" + số từ 1-5
    match = re.search(r"NH[OÓ]M\s*([1-5])", value)
    if match:
        return f"N{match.group(1)}"
    # Nếu chỉ là số từ 1-5
    if value in ["1", "2", "3", "4", "5"]:
        return f"N{value}"
    # Các trường hợp còn lại
    return "Khác"


def _transform_source_new(file_path):
    """
    Đọc và chuyển đổi dữ liệu từ file XML (định dạng xuất từ Excel).
    Bước xử lý:
    - Parse XML bằng BeautifulSoup
    - Tìm dòng header
    - Tạo DataFrame với các cột chuẩn
    - Ép kiểu dữ liệu (ngày, số)
    """
    # print(f"Processing file {file_path}")
    logger.info(f"Processing file {file_path}")

    with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
        content = f.read()
    # Parse bằng BeautifulSoup
    soup = BeautifulSoup(content, "xml")

    # Lấy tất cả các dòng trong bảng
    rows = soup.find_all("Row")

    data = []
    for row in rows:
        cells = [cell.get_text(strip=True) for cell in row.find_all("Data")]
        if cells:
            data.append(cells)

    header_idx = next((i for i, r in enumerate(data) if "loai_thau" in r), None)
    # max_len = max(len(r) for r in data)
    # header_idx = next(i for i, r in enumerate(data) if len(r) == max_len)
    # Tạo DataFrame
    df = pd.DataFrame(data[header_idx + 1 :], columns=data[header_idx])
    df = df[
        [
            "nhasx",
            "nuocsx",
            "donvitinh",
            "soluong",
            "gia",
            "thanhtien",
            "nhomthau",
            "congbo",
            "tungay_hd",
            "denngay_hd",
            "created_date",
        ]
    ]
    df["donvitinh"] = df["donvitinh"].str.lower()
    col_date = ["congbo", "tungay_hd", "denngay_hd", "created_date"]
    col_num = ["soluong", "gia", "thanhtien"]

    for col in col_date:
        df[col] = pd.to_datetime(df[col], errors="coerce")
    for col in col_num:
        df[col] = pd.to_numeric(df[col])

    return df


def process_kqtt_files(file_list, existing_df=None, update_log=False, log_file=None):
    """
    Xử lý danh sách file KQTT (Kết quả trúng thầu).

    Quy trình:
    - Nếu danh sách file rỗng → log "skip" và trả về existing_df hoặc DataFrame rỗng.
    - Đọc & transform từng file XML.
    - Hợp nhất các file hợp lệ.
    - Lọc dữ liệu, chuẩn hóa đơn vị.
    - Ghi parquet và cập nhật log nếu được yêu cầu.

    Parameters
    ----------
    file_list : list[str]
        Danh sách file cần xử lý.
    existing_df : pd.DataFrame, optional
        DataFrame lịch sử (để gộp thêm dữ liệu mới).
    update_log : bool, optional
        Có cập nhật log sau khi xử lý hay không.
    log_file : str, optional
        Đường dẫn file log.

    Returns
    -------
    pd.DataFrame
        Dữ liệu sau khi xử lý; trả về DataFrame lịch sử nếu không có file mới.
    """
    logger.info("_________________Transform KQTTT_________________")
    if not file_list:
        logger.info("Process_kqtt_files: Không có file mới nào cần xử lý")
        # Nếu cần cập nhật log với danh sách rỗng thì không làm gì
        return (
            existing_df.copy()
            if isinstance(existing_df, pd.DataFrame)
            else pd.DataFrame()
        )
    df_all, file_error = [], []

    for file in file_list:
        try:
            df = _transform_source_new(os.path.join(DATA_RAW_PATH, "kqtt", file))
            if df.empty:
                continue
            df["file"] = file
            df_all.append(df)
            logger.info(f"Done transform KQTT {file}")
        except Exception as e:
            logger.error(f"Error in transform {file}: {e}")
            file_error.append(file)

    if update_log and log_file:
        processed = list(set(file_list) - set(file_error))
        # Chỉ ghi lại phần tên k bao gồm path
        processed = [str(Path(file).name) for file in processed]
        if processed:
            update_processed_log(log_file, processed)

    if not df_all:
        logger.warning("Không có file nào được xử lý hợp lệ.")
        return existing_df if existing_df is not None else pd.DataFrame()

    df_all = pd.concat(df_all, ignore_index=True)

    df_all["unit_clean"] = df_all["donvitinh"].apply(clean_unit)
    df_all["nhomthau"] = df_all["nhomthau"].apply(normalize_nhomthau)

    # Gộp dữ liệu cũ nếu có
    if existing_df is not None:
        df_all = pd.concat([df_all, existing_df], ignore_index=True)

    df_all = df_all[df_all["nhasx"].notna()]
    df_all = df_all.drop_duplicates()
    df_all.to_parquet(os.path.join(DATA_TRANS_PATH, "kqtrungthau.parquet"))
    logger.warning(f"List error file: {file_error}")
    logger.info("__________________DONE ALL tranform KQTT________________")
    return df_all


def transform_kqtt_hist():
    """Xử lý toàn bộ lịch sử file KQTT (chạy lần đầu tiên)."""
    list_file = [f for f in os.listdir(f"{DATA_RAW_PATH}/kqtt") if f.endswith(".xls")]
    return process_kqtt_files(list_file)


def transform_kqtt():
    """Chỉ xử lý các file mới chưa được xử lý."""
    path_kqtt = os.path.join(DATA_RAW_PATH, "kqtt")
    log_file = os.path.join(path_kqtt, "log_processed_file.csv")
    file_unprocess = find_unprocessed_files(path_kqtt, log_path=log_file, ext="xls")
    df_hist = pd.read_parquet(os.path.join(DATA_TRANS_PATH, "kqtrungthau.parquet"))
    return process_kqtt_files(
        file_unprocess, existing_df=df_hist, update_log=True, log_file=log_file
    )


def kqtt_chart():
    logger.info("_________________Chart KQTT_________________")
    df = pd.read_parquet(os.path.join(DATA_TRANS_PATH, "kqtrungthau.parquet"))
    df["nuocsx_clean"] = (
        df["nuocsx"]
        .astype(str)
        .apply(lambda x: "Việt Nam" if "nam" in x.lower() else "Nước ngoài")
    )
    df["congbo"] = pd.to_datetime(df["congbo"])
    df["month"] = df["congbo"].dt.to_period("M")
    df["nuocsx_clean"] = (
        df["nuocsx"]
        .astype(str)
        .apply(lambda x: "Việt Nam" if "nam" in x.lower() else "Nước ngoài")
    )
    df_group = (
        df.groupby(["nuocsx_clean", "nhomthau", "month"])[
            ["soluong", "thanhtien"]
        ]
        .sum()
        .reset_index()
    )
    # Tạo dòng tổng theo nhomthau
    df_total = (
        df.groupby(["nuocsx_clean", "month"])[["soluong", "thanhtien"]]
        .sum()
        .reset_index()
    )

    df_total["nhomthau"] = "Tổng"

    # Ghép vào df_group
    df_final = pd.concat([df_group, df_total], ignore_index=True)

    df_final = df_final[df_final["month"].notnull()]
    df_final["month"] = df_final["month"].astype("str")
    df_final.to_parquet(os.path.join(DATA_CHART_PATH, "kqtt.parquet"))
    df_final[["month"]].drop_duplicates().sort_values("month").to_parquet(
        os.path.join(DATA_CHART_PATH, "kqtt_dropdown_month.parquet")
    )
    df_final[["nuocsx_clean"]].drop_duplicates().sort_values("nuocsx_clean").to_parquet(
        os.path.join(DATA_CHART_PATH, "kqtt_dropdown_country.parquet")
    )
    logger.info("_________________DONE chart KQTT_________________")


if __name__ == "__main__":
    # transform_kqtt_hist()
    transform_kqtt()
    kqtt_chart()
