import pandas as pd
import os
import sys
import tabula

# Set JAVA_PATH for both local and Docker environments
if os.path.exists("/usr/lib/jvm/default-java"):
    # Docker environment
    java_path = "/usr/lib/jvm/default-java/bin"
else:
    # Local Windows environment
    java_path = r"C:\Program Files\Java\jdk-21\bin"

os.environ["PATH"] = java_path + (":" if os.name == "posix" else ";") + os.environ["PATH"]

from PyPDF2 import PdfReader
from datetime import date
import re

curr_path = os.path.dirname(os.path.abspath(__file__))
parent_path = curr_path.split("src")[0]
sys.path.append(parent_path)
from src.utils.logs import get_logger  # noqa: E402
from src.utils.helper import update_processed_log, find_unprocessed_files  # noqa: E402
from src.utils.configs import (  # noqa: E402
    DATA_INPUT_IMPORT_QG,
    DATA_INPUT_IMPORT_MH,
    DATA_TRANS_PATH,
    DATA_RAW_PATH,
    DATA_CHART_PATH,
)

logger = get_logger()


# Lấy tạm dữ liệu cũ
# TODO: Viết lại file đọc pdf
def convert_to_number(s: pd.Series) -> pd.Series:
    """
    Chuyển Series dạng '1.234.567,89' -> float 1234567.89
    Áp dụng vectorized, không dùng apply.
    """
    # Chuyển sang string, loại bỏ khoảng trắng
    s_str = s.astype(str).str.replace(" ", "", regex=False)
    # Bỏ dấu nghìn '.'
    s_str = s_str.str.replace(".", "", regex=False)
    # Đổi dấu thập phân ',' -> '.'
    s_str = s_str.str.replace(",", ".", regex=False)
    # Chuyển sang float, lỗi -> NaN
    return pd.to_numeric(s_str, errors="coerce")


def read_pdf_mh(file):
    # input_path = os.path.join(DATA_RAW_PATH, r"xnk\\XNK_thang")
    pdf_path = file
    name_file = os.path.basename(pdf_path)
    logger.info(f"Reading file: {name_file}")
    temp_csv = pdf_path.replace(".pdf", "_tmp.csv")
    i_month = re.findall(r"\d+", name_file)[1]
    i_year = re.findall(r"\d+", name_file)[0]
    tabula.convert_into(
        pdf_path,
        temp_csv,
        output_format="csv",
        pages="all",
        lattice=True,
        force_subprocess=True,
    )

    # Đọc CSV linh hoạt
    try:
        df = pd.read_csv(temp_csv, encoding="utf-8", on_bad_lines="skip", header=1)
    except UnicodeDecodeError:
        df = pd.read_csv(temp_csv, encoding="latin-1", on_bad_lines="skip", header=1)
    df.columns = [
        "no",
        "main_product",
        "unit",
        "quantity",
        "value_usd",
        "mom_quantity",
        "mom_value",
        "quantity_cum",
        "value_cum",
        "yoy_quantity_cum",
        "yoy_value_cum",
    ]
    df = df[df["unit"].isin(["USD", "Tấn", "Chiếc"])]
    df["month"] = date(int(i_year), int(i_month), 28)
    df = df[df["main_product"].notna()]
    df["status"] = name_file.split("(")[1].split("-")[1].split(")")[0].upper()
    cols_to_convert = [
        "quantity",
        "value_usd",
        "mom_quantity",
        "mom_value",
        "quantity_cum",
        "value_cum",
        "yoy_quantity_cum",
        "yoy_value_cum",
    ]

    for col in cols_to_convert:
        df[col] = convert_to_number(df[col])
    if os.path.exists(temp_csv):
        os.remove(temp_csv)
    # tb['month'] = datetime.strptime
    return df


def read_pdf_qg(file):
    """
    - Dùng tabula.convert_into để kiểm soát encoding
    - Bỏ qua dòng lỗi, tránh crash & UTF-8 lỗi
    - Trả về DataFrame đầy đủ
    """
    # input_path = os.path.join(DATA_RAW_PATH, r"xnk\\XNK_QG")
    pdf_path = file
    name_file = os.path.basename(pdf_path)
    temp_csv_p1 = pdf_path.replace(".pdf", "_tmp_p1.csv")
    temp_csv = pdf_path.replace(".pdf", "_tmp.csv")
    i_month = re.findall(R"\d+", name_file)[1]
    i_year = re.findall(R"\d+", name_file)[0]
    # os.environ["JAVA_TOOL_OPTIONS"] = "-Xmx2G"

    try:
        logger.info(f"Reading file: {name_file}")
        reader = PdfReader(open(pdf_path, mode="rb"))
        n_pages = len(reader.pages)
        # Xuất PDF sang CSV tạm (toàn bộ file)
        tabula.convert_into(
            pdf_path,
            temp_csv_p1,
            output_format="csv",
            area=[[180, 55, 800, 600]],
            pages="1",
            stream=True,
            force_subprocess=True,
        )
        try:
            df_p1 = pd.read_csv(temp_csv_p1, encoding="utf-8", on_bad_lines="skip")
        except UnicodeDecodeError:
            df_p1 = pd.read_csv(temp_csv_p1, encoding="latin-1", on_bad_lines="skip")

        if n_pages >= 2:
            tabula.convert_into(
                pdf_path,
                temp_csv,
                output_format="csv",
                area=[[80, 55, 800, 600]],
                columns=[275, 310, 364, 434, 489],
                pages=f"2-{n_pages}",
                stream=True,
                force_subprocess=True,
            )
            try:
                df = pd.read_csv(temp_csv, encoding="utf-8", on_bad_lines="skip")
            except UnicodeDecodeError:
                df = pd.read_csv(temp_csv, encoding="latin-1", on_bad_lines="skip")
            df = pd.concat([df_p1, df], ignore_index=True)

        else:
            df = pd.DataFrame()

        # Chuẩn hóa tên cột
        df.columns = [
            "country/main_product",
            "unit",
            "quantity",
            "value_usd",
            "quantity_cum",
            "value_cum",
        ]
        df["month"] = date(int(i_year), int(i_month), 28)
        df = df[df["country/main_product"].notna()]
        df.loc[df["unit"].isna(), "country"] = df["country/main_product"]
        df["country"] = df["country"].ffill()
        df["status"] = name_file.split("(")[1].split("-")[1].split(")")[0].upper()
        logger.info(f"Read {len(df)} rows {name_file}")
        cols_to_convert = [
            "quantity",
            "value_usd",
            "quantity_cum",
            "value_cum",
        ]
        for col in cols_to_convert:
            df[col] = convert_to_number(df[col])

        return df
    except Exception as e:
        logger.error(f"Error when read file {file}: {e}")
        return None

    finally:
        for f in [temp_csv, temp_csv_p1]:
            if os.path.exists(f):
                os.remove(f)


# Xử lý tạm thời từ file đã xử lý
def _import_quocgia(file):
    # df = pd.read_excel(DATA_INPUT_IMPORT_QG)
    df = read_pdf_qg(file)
    df = df.rename(columns={"country/main_product": "main_product"})
    df = df[
        df["main_product"]
        .astype(str)
        .str.lower()
        # .str.replace(r"\s+", "", regex=True)
        .str.contains("dược phẩm", na=False)
    ]
    
    df["month"] = pd.to_datetime(df["month"]).dt.strftime("%Y-%m")
    df.columns = df.columns.str.lower()
    # logger.info(df)
    return df


def _import_mathang(file):
    # df = pd.read_excel(DATA_INPUT_IMPORT_MH)
    df = read_pdf_mh(file)
    df = df[
        df["main_product"].astype(str).str.lower().str.contains("dược phẩm", na=False)
    ]
    df.columns = df.columns.str.lower()
    df["country"] = "TỔNG CỘNG"
    df["month"] = pd.to_datetime(df["month"]).dt.strftime("%Y-%m")
    # logger.info(df)
    return df


def hist_import():
    df_qg = pd.read_excel(DATA_INPUT_IMPORT_QG)
    df_qg.columns = [
        "country/main_product",
        "country",
        "unit",
        "quantity",
        "value_usd",
        "quantity_cum",
        "value_cum",
        "month",
        "status",
    ]
    df_qg = df_qg[
        df_qg["country/main_product"]
        .astype(str)
        .str.lower()
        .str.contains("dược phẩm", na=False)
    ]

    df_qg = df_qg.rename(columns={"country/main_product": "main_product"})
    df_qg["month"] = pd.to_datetime(df_qg["month"]).dt.strftime("%Y-%m")

    df_mh = pd.read_excel(DATA_INPUT_IMPORT_MH)
    df_mh.columns = [
        "main_product",
        "unit",
        "quantity",
        "value_usd",
        "mom_quantity",
        "mom_value",
        "quantity_cum",
        "value_cum",
        "yoy_quantity_cum",
        "yoy_value_cum",
        "month",
        "status",
    ]
    df_mh = df_mh[
        df_mh["main_product"]
        .astype(str)
        .str.lower()
        .str.contains("dược phẩm", na=False)
    ]
    df_mh.columns = df_mh.columns.str.lower()
    df_mh["country"] = "TỔNG CỘNG"
    df_mh["month"] = pd.to_datetime(df_mh["month"]).dt.strftime("%Y-%m")
    df = pd.concat([df_qg, df_mh], ignore_index=True)
    df = df.drop(
        columns=[
            "mom_quantity",
            "mom_value",
            "yoy_quantity_cum",
            "yoy_value_cum",
        ]
    )
    df.sort_values(["country", "month"], inplace=True)

    return df


def transform_import():
    logger.info(
        "___________Start Transform Nhap khau duoc pham - Customs_______________"
    )
    df_hist = hist_import()
    path_xnk = rf"{DATA_RAW_PATH}/xnk"
    log_file = os.path.join(path_xnk, "log_processed_file.csv")
    unprocessed_files = find_unprocessed_files(
        path_xnk, log_file, ext=".pdf", recursive=True
    )
    df_list = []
    if not unprocessed_files:
        logger.info("No new files to process")
        return
    # logger.info(unprocessed_files)
    list_file = [i for i in unprocessed_files if "5n" in i.lower() or "2n" in i.lower()]
    success_file = []
    for f in list_file:
        if "XNK_QG" in f:
            df_temp = _import_quocgia(f)  # xử lý 1 file
            # print(df_temp.head())
        elif "XNK_thang" in f:
            df_temp = _import_mathang(f)  # xử lý 1 file
            # print(df_temp.head())
        else:
            continue  # bỏ qua file không nhận diện

        if not df_temp.empty:
            df_list.append(df_temp)
            # chỉ lấy phần sau bỏ phần path đầu /app/data/raw/xnk/ để lưu vào log
            success_file.append(f.split(path_xnk)[-1] if path_xnk in f else f)
    # chỉ thêm file đã xử lý thành công

    if df_list:
        df = pd.concat(df_list, ignore_index=True)
        df = df.drop(
            columns=[
                "no",
                "mom_quantity",
                "mom_value",
                "yoy_quantity_cum",
                "yoy_value_cum",
            ]
        )
        df = pd.concat([df, df_hist], ignore_index=True)
        df = df.drop_duplicates(subset=["main_product", "country", "month"])
        df = df.sort_values(["country", "month"]).reset_index(drop=True)

        df.to_parquet(rf"{DATA_TRANS_PATH}/import_custom.parquet")

        update_processed_log(log_file, new_files=success_file)
    logger.info("_________________DONE Transform NK duoc pham_________________")
    # return df


def xnk_chart():
    df = pd.read_parquet(rf"{DATA_TRANS_PATH}/import_custom.parquet")
    df[["main_product", "value_usd", "value_cum", "month", "country"]].to_parquet(
        rf"{DATA_CHART_PATH}/import_custom.parquet"
    )
    df[["country"]].drop_duplicates().sort_values("country").to_parquet(
        rf"{DATA_CHART_PATH}/import_custom_dropdown_country.parquet"
    )


if __name__ == "__main__":
    transform_import()
    xnk_chart()
