import pandas as pd
import os
import sys

curr_path = os.path.dirname(os.path.abspath(__file__))
parent_path = curr_path.split("src")[0]
sys.path.append(parent_path)
from src.utils.configs import DATA_INPUT_BMI, DATA_TRANS_PATH  # noqa: E402
from src.utils.logs import get_logger  # noqa: E402

logger = get_logger()


def melt_df(data):
    return data.melt(id_vars="Indicator", var_name="year", value_name="revenue")


def transform_bmi():
    logger.info("___________Transfrom BMI___________")
    df = pd.read_excel(DATA_INPUT_BMI, sheet_name=None)
    df_all = []
    del df["Hướng dẫn"]
    df_update = df['Thời gian cập nhật']
    df_update = df_update.iloc[0, 0]
    del df['Thời gian cập nhật']
    for sheet_name, df0 in df.items():
        print(sheet_name)
        df0.columns = df0.iloc[0, :]
        df0 = df0.drop(index=[0])
        df_ = melt_df(df0)
        df_ = (
            df_.rename(columns={"Indicator": "indicator"})
            .astype({"year": "str"})
            .assign(type_revenue=sheet_name)
        )
        df_all.append(df_)
    df_all = pd.concat(df_all, ignore_index=True)
    df_all['time_update'] = df_update
    # print(df_all.head())
    df_all.to_parquet(rf"{DATA_TRANS_PATH}/bmi.parquet")
    logger.info("__________DONE Transform BMI____________")
    return df_all


if __name__ == "__main__":
    transform_bmi()
