import pandas as pd
import os
import sys
import re

curr_path = os.path.dirname(os.path.abspath(__file__))
parent_path = curr_path.split("src")[0]
sys.path.append(parent_path)
from src.utils.configs import DATA_RAW_PATH, DATA_TRANS_PATH  # noqa: E402
from src.utils.logs import get_logger  # noqa: E402

logger = get_logger()


def _transform_gmp(file_type):
    folder_file = rf"{DATA_RAW_PATH}/gmp"
    if file_type == "gmp":
        list_file = [i for i in os.listdir(folder_file) if "gmp_20" in i]
    elif file_type == "gmp_baobi":
        list_file = [i for i in os.listdir(folder_file) if "gmp_baobi" in i]
    # print(list_file)
    sorted(list_file)
    df_all = []
    for file in list_file:
        match = re.search(r"(\d{4}-\d{2}-\d{2})", file)
        if match:
            date_str = match.group(1)
        df = pd.read_excel(
            rf"{folder_file}/{file_type}_{date_str}.xlsx", header=None, skiprows=6
        )
        if len(df.columns) == 8:
            df.columns = [
                "no",
                "facility_name",
                "HO_address",
                "branch_name",
                "facility_address",
                "responsibility",
                "certification_scope",
                "certification"
            ]
        elif len(df.columns) == 9:
            df.columns = [
                "no",
                "facility_name",
                "facility_address",
                "certification_scope",
                "standard",
                "certifying_agency",
                "certificate_code",
                "issue_date",
                "expiry_date",
            ]
        elif len(df.columns) == 13:
            df.columns = [
                "no",
                "id_cs",
                "id_cc",
                "id_cty",
                "ma_dc",
                "facility_name",
                "facility_address",
                "certification_scope",
                "standard",
                "certifying_agency",
                "certificate_code",
                "issue_date",
                "expiry_date",
            ]
            df = df.drop(
                columns=[
                    "id_cs",
                    "id_cc",
                    "id_cty",
                    "ma_dc",
                ]
            )

        elif len(df.columns) == 15:
            df.columns = [
                "id",
                "no",
                "facility_name",
                "id1",
                "facility_address",
                "certification_scope",
                "id2",
                "standard",
                "certifying_agency",
                "id3",
                "certificate_code",
                "id4",
                "issue_date",
                "id5",
                "expiry_date",
            ]
            df = df.drop(
                columns=[
                    "id",
                    "id1",
                    "id2",
                    "id3",
                    "id4",
                    "id5"
                ]
            )
            df = df[
                (df["facility_name"].ne("TÊN CƠ SỞ")) &
                (df["facility_name"].notna()) &
                (df["facility_name"].str.strip().ne(""))
            ]

        else:
            df.columns = [
                "no",
                "facility_name",
                "facility_address",
                "city",
                "area",
                "certification_scope",
                "standard",
                "certifying_agency",
                "certificate_code",
                "issue_date",
                "expiry_date",
            ]
            df = df.drop(
                columns=[
                    "city",
                    "area"
                ]
            )
        # # Nếu không có cột standard thì tạo cột này với giá trị là WHO_GMP
        # if "standard" not in df.columns:
        #     df["standard"] = "WHO-GMP"
        # # Nếu có các cột như HO_address, branch_name, responsibility, certification thì xóa 
        # if ["HO_address", "branch_name", "responsibility"] == df.columns.tolist():
        #     df = df.drop(columns=["HO_address", "branch_name", "responsibility"])
        
        # df = df.rename(columns={"certification": "certification_code"})
        # # Nếu không có cột issue_date thì tạo cột với giá trị ngày trong tên file
        # if "issue_date" not in df.columns and "expiry_date" not in df.columns:
        #     df["issue_date"] = date_str
        #     df["expiry_date"] = date_str

        print(file)
        print(df.columns)
        df.loc[df["certification_scope"].isna(), "code_name"] = df["facility_name"]
        df["code_name"] = df["code_name"].ffill()
        df = df[df.certification_scope.notna()]
        df["date"] = date_str
        df["date"] = pd.to_datetime(df["date"])
        df["issue_date"] = pd.to_datetime(df["issue_date"], errors='coerce')
        df["expiry_date"] = pd.to_datetime(df["expiry_date"], errors='coerce')

        col_sort = [
            "no",
            "code_name",
            "date",
            "facility_name",
            "facility_address",
            "certification_scope",
            "standard",
            "certifying_agency",
            "certificate_code",
            "issue_date",
            "expiry_date",
        ]
        df['certificate_code'] = df['certificate_code'].astype('str')
        df = df.reindex(columns=col_sort)
        df_all.append(df)
    df_all = pd.concat(df_all, ignore_index=True)
    mask = df_all["standard"].astype(str).str.contains("WHO", case=False, na=False)
    df_all.loc[mask, "standard"] = "WHO-GMP"
    df_all.loc[df_all["standard"].astype(str).str.contains("Japan", case=False, na=False), "standard"] = "Japan-GMP"
    df_all.loc[~df_all["standard"].isin(['WHO-GMP', 'EU-GMP', 'Japan-GMP']), "standard"] = "Khác"

    df_all.to_parquet(rf"{DATA_TRANS_PATH}/{file_type}_full.parquet")
    return df_all


def transform_all_gmp():
    logger.info("____________Transfrom Company_share - GMP__________")
    _transform_gmp("gmp")
    _transform_gmp("gmp_baobi")
    logger.info("____________DONE Company_share - GMP__________")


if __name__ == "__main__":
    transform_all_gmp()
