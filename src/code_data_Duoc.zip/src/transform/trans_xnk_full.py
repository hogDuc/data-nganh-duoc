import pandas as pd
import os
import sys
import tabula
from PyPDF2 import PdfReader
from datetime import date
import re

curr_path = os.path.dirname(os.path.abspath(__file__))
parent_path = curr_path.split("src")[0]
sys.path.append(parent_path)
from src.utils.logs import get_logger  # noqa: E402
from src.utils.helper import update_processed_log, find_unprocessed_files  # noqa: E402
from src.utils.configs import (  # noqa: E402
    DATA_INPUT_IMPORT_QG,
    DATA_INPUT_IMPORT_MH,
    DATA_TRANS_PATH,
    DATA_RAW_PATH,
    DATA_CHART_PATH,
)

logger = get_logger()


# Lấy tạm dữ liệu cũ
# TODO: Viết lại file đọc pdf
def convert_to_number(s: pd.Series) -> pd.Series:
    """
    Chuyển Series dạng '1.234.567,89' -> float 1234567.89
    Áp dụng vectorized, không dùng apply.
    """
    # Chuyển sang string, loại bỏ khoảng trắng
    s_str = s.astype(str).str.replace(" ", "", regex=False)
    # Bỏ dấu nghìn '.'
    s_str = s_str.str.replace(".", "", regex=False)
    # Đổi dấu thập phân ',' -> '.'
    s_str = s_str.str.replace(",", ".", regex=False)
    # Chuyển sang float, lỗi -> NaN
    return pd.to_numeric(s_str, errors="coerce")


def read_pdf_mh(file):
    # input_path = os.path.join(DATA_RAW_PATH, r"xnk\\XNK_thang")
    pdf_path = file
    name_file = os.path.basename(pdf_path)
    logger.info(f"Reading file: {name_file}")
    temp_csv = pdf_path.replace(".pdf", "_tmp.csv")
    i_month = re.findall(r"\d+", name_file)[1]
    i_year = re.findall(r"\d+", name_file)[0]
    tabula.convert_into(
        pdf_path,
        temp_csv,
        output_format="csv",
        pages="all",
        lattice=True,
        force_subprocess=True,
    )

    # Đọc CSV linh hoạt
    try:
        df = pd.read_csv(temp_csv, encoding="utf-8", on_bad_lines="skip", header=1)
    except UnicodeDecodeError:
        df = pd.read_csv(temp_csv, encoding="latin-1", on_bad_lines="skip", header=1)
    df.columns = [
        "no",
        "main_product",
        "unit",
        "quantity",
        "value_usd",
        "mom_quantity",
        "mom_value",
        "quantity_cum",
        "value_cum",
        "yoy_quantity_cum",
        "yoy_value_cum",
    ]
    df = df[df["unit"].isin(["USD", "Tấn", "Chiếc"])]
    df["month"] = date(int(i_year), int(i_month), 28)
    df = df[df["main_product"].notna()]
    df["status"] = name_file.split("(")[1].split("-")[1].split(")")[0].upper()
    cols_to_convert = [
        "quantity",
        "value_usd",
        "mom_quantity",
        "mom_value",
        "quantity_cum",
        "value_cum",
        "yoy_quantity_cum",
        "yoy_value_cum",
    ]

    for col in cols_to_convert:
        df[col] = convert_to_number(df[col])
    if os.path.exists(temp_csv):
        os.remove(temp_csv)
    # tb['month'] = datetime.strptime
    return df


def read_pdf_qg(file):
    """
    - Dùng tabula.convert_into để kiểm soát encoding
    - Bỏ qua dòng lỗi, tránh crash & UTF-8 lỗi
    - Trả về DataFrame đầy đủ
    """
    # input_path = os.path.join(DATA_RAW_PATH, r"xnk\\XNK_QG")
    pdf_path = file
    name_file = os.path.basename(pdf_path)
    temp_csv_p1 = pdf_path.replace(".pdf", "_tmp_p1.csv")
    temp_csv = pdf_path.replace(".pdf", "_tmp.csv")
    i_month = re.findall(R"\d+", name_file)[1]
    i_year = re.findall(R"\d+", name_file)[0]
    # os.environ["JAVA_TOOL_OPTIONS"] = "-Xmx2G"

    try:
        logger.info(f"Reading file: {name_file}")
        reader = PdfReader(open(pdf_path, mode="rb"))
        n_pages = len(reader.pages)
        # Xuất PDF sang CSV tạm (toàn bộ file)
        tabula.convert_into(
            pdf_path,
            temp_csv_p1,
            output_format="csv",
            area=[[180, 55, 800, 600]],
            pages="1",
            stream=True,
            force_subprocess=True,
        )
        try:
            df_p1 = pd.read_csv(temp_csv_p1, encoding="utf-8", on_bad_lines="skip")
        except UnicodeDecodeError:
            df_p1 = pd.read_csv(temp_csv_p1, encoding="latin-1", on_bad_lines="skip")

        if n_pages >= 2:
            tabula.convert_into(
                pdf_path,
                temp_csv,
                output_format="csv",
                area=[[80, 55, 800, 600]],
                columns=[275, 310, 364, 434, 489],
                pages=f"2-{n_pages}",
                stream=True,
                force_subprocess=True,
            )
            try:
                df = pd.read_csv(temp_csv, encoding="utf-8", on_bad_lines="skip")
            except UnicodeDecodeError:
                df = pd.read_csv(temp_csv, encoding="latin-1", on_bad_lines="skip")
            df = pd.concat([df_p1, df], ignore_index=True)

        else:
            df = pd.DataFrame()

        # Chuẩn hóa tên cột
        df.columns = [
            "country/main_product",
            "unit",
            "quantity",
            "value_usd",
            "quantity_cum",
            "value_cum",
        ]
        df["month"] = date(int(i_year), int(i_month), 28)
        df = df[df["country/main_product"].notna()]
        df.loc[df["unit"].isna(), "country"] = df["country/main_product"]
        df["country"] = df["country"].ffill()
        df["status"] = name_file.split("(")[1].split("-")[1].split(")")[0].upper()
        logger.info(f"Read {len(df)} rows {name_file}")
        cols_to_convert = [
            "quantity",
            "value_usd",
            "quantity_cum",
            "value_cum",
        ]
        for col in cols_to_convert:
            df[col] = convert_to_number(df[col])

        return df
    except Exception as e:
        logger.error(f"Error when read file {file}: {e}")
        return None

    finally:
        for f in [temp_csv, temp_csv_p1]:
            if os.path.exists(f):
                os.remove(f)


def transform_full_xnk():
    df_qg_hist = pd.read_excel(
        r"D:\OneDrive - fpts.com.vn\APD - projects\FPA_dashboard\data\input\XNK_QG_full.xlsx",
        sheet_name=None,
    )
    df_qg_hist_xk = df_qg_hist["XK_TT"]
    df_qg_hist_nk = df_qg_hist["NK_TT"]
    df_qg_hist_xk.columns = [
        "country/main_product",
        "country",
        "unit",
        "quantity",
        "value_usd",
        "quantity_cum",
        "value_cum",
        "month",
        "status",
    ]
    df_qg_hist_nk.columns = [
        "country/main_product",
        "country",
        "unit",
        "quantity",
        "value_usd",
        "quantity_cum",
        "value_cum",
        "month",
        "status",
    ]
    df_mh_hist = pd.read_excel(
        r"D:\OneDrive - fpts.com.vn\APD - projects\FPA_dashboard\data\input\XNK_mathang_full.xlsx",
        sheet_name=None,
    )
    df_mh_hist_xk = df_mh_hist["XK_mathang"]
    df_mh_hist_nk = df_mh_hist["NK_mathang"]

    df_mh_hist_xk.columns = [
        "main_product",
        "unit",
        "quantity",
        "value_usd",
        "mom_quantity",
        "mom_value",
        "quantity_cum",
        "value_cum",
        "yoy_quantity_cum",
        "yoy_value_cum",
        "month",
        "status",
        "action",
    ]
    df_mh_hist_nk.columns = [
        "main_product",
        "unit",
        "quantity",
        "value_usd",
        "mom_quantity",
        "mom_value",
        "quantity_cum",
        "value_cum",
        "yoy_quantity_cum",
        "yoy_value_cum",
        "month",
        "status",
        "action",
    ]
    path_mh = (
        r"D:\OneDrive - fpts.com.vn\APD - projects\FPA_dashboard\data\raw\xnk\XNK_thang"
    )
    path_qg = (
        r"D:\OneDrive - fpts.com.vn\APD - projects\FPA_dashboard\data\raw\xnk\XNK_QG"
    )
    list_mh = os.listdir(path_mh)
    list_qg = os.listdir(path_qg)
    for i in list_mh:
        if "2n" in i.lower():
            df_nk = read_pdf_mh(os.path.join(path_mh, i))
            df_nk["action"] = "NK"
            df_mh_hist_nk = pd.concat([df_mh_hist_nk, df_nk], ignore_index=True)
        elif "2x" in i.lower():
            df_xk = read_pdf_mh(os.path.join(path_mh, i))
            df_xk["action"] = "XK"
            df_mh_hist_xk = pd.concat([df_mh_hist_xk, df_xk], ignore_index=True)
    for i in list_qg:
        if "5n" in i.lower():
            df_nk = read_pdf_qg(os.path.join(path_qg, i))
            df_qg_hist_nk = pd.concat([df_qg_hist_nk, df_nk], ignore_index=True)
        elif "5x" in i.lower():
            df_xk = read_pdf_qg(os.path.join(path_qg, i))
            df_qg_hist_xk = pd.concat([df_qg_hist_xk, df_xk], ignore_index=True)

    df_mh_hist_xk["month"] = pd.to_datetime(df_mh_hist_xk["month"]).dt.strftime("%Y-%m")
    df_mh_hist_nk["month"] = pd.to_datetime(df_mh_hist_nk["month"]).dt.strftime("%Y-%m")

    # df_qg_hist_xk["month"] = pd.to_datetime(df_qg_hist_xk["month"]).dt.strftime("%Y-%m")
    # df_qg_hist_nk["month"] = pd.to_datetime(df_qg_hist_nk["month"]).dt.strftime("%Y-%m")

    with pd.ExcelWriter(
        r"D:\OneDrive - fpts.com.vn\APD - projects\FPA_dashboard\data\input\import_mathang_full_20251218.xlsx"
    ) as a:
        df_mh_hist_xk.to_excel(a, sheet_name="XK")
        df_mh_hist_nk.to_excel(a, sheet_name="NK")
    with pd.ExcelWriter(
        r"D:\OneDrive - fpts.com.vn\APD - projects\FPA_dashboard\data\input\import_quocgia_full_20251218.xlsx"
    ) as a:
        df_qg_hist_xk.to_excel(a, sheet_name="XK")
        df_qg_hist_nk.to_excel(a, sheet_name="NK")


if __name__ == "__main__":
    # transform_import()
    transform_full_xnk()
