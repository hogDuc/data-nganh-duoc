import pandas as pd
import os
import sys
import re

curr_path = os.path.dirname(os.path.abspath(__file__))
parent_path = curr_path.split("src")[0]
sys.path.append(parent_path)
from src.utils.configs import DATA_RAW_PATH, DATA_TRANS_PATH  # noqa: E402
from src.utils.logs import get_logger  # noqa: E402

folder_file = rf"{DATA_RAW_PATH}/iip"


def _transform(data, name_file):
    df_final = data.iloc[:, [0, 1, -3, -2, -1]]
    df_final.columns = ["id_code", "industry", "mom", "yoy", "luyke_yoy"]
    df_final = df_final.drop(index=[0, 1, 2, 3])
    part = name_file.split("_")[1].split(".")[0]
    result = f"{part[:4]}-{part[4:]}"
    df_final["month"] = result
    df_final = df_final[df_final.id_code == 21]
    df_final = df_final.drop(columns="id_code")
    return df_final


def _transform_file_base_2015(data, name_file):
    df_m = data.iloc[:, 0:-3]
    name_col = ["id_code", "industry"]
    if "12.xlsx" in name_file:
        mask = df_m.apply(
            lambda row: row.astype(str).str.contains("Tháng 11", case=False, na=False)
        ).any(axis=1)
        row_month = df_m.loc[mask].iloc[0, 2:]
        name_col.extend(row_month)
    else:
        name_col.extend(df_m.iloc[2, 2:])
    part = name_file.split("_")[1].split(".")[0]
    new_cols = [i.replace("Tháng ", part[:4] + "-") for i in name_col]
    new_cols = [re.sub(r"-(\d{1})$", lambda m: f"-0{m.group(1)}", c) for c in new_cols]
    df_m.columns = new_cols
    df_m = df_m.drop(index=[0, 1, 2, 3])
    df_m = (
        df_m[df_m.id_code == 21]
        .drop(columns="id_code")
        .melt(id_vars="industry", var_name="month", value_name="iip_base2015")
    )
    return df_m


def get_latest_files_year(folder: str):
    """
    Trả về danh sách tên file IIP cuối cùng (tháng lớn nhất) của mỗi năm trong thư mục.
    File có định dạng: IIP_YYYYMM.xlsx hoặc IIP_YYYYMM.xls
    """
    files = os.listdir(folder)
    if not files:
        return []

    data = []
    for f in files:
        match = re.search(r"IIP_(\d{4})(\d{2})", f)
        if match:
            year, month = match.groups()
            data.append((int(year), int(month), f))

    if not data:
        return []

    df = pd.DataFrame(data, columns=["year", "month", "filename"])
    latest_files = (
        df.loc[df.groupby("year")["month"].idxmax()]
        .sort_values("year")["filename"]
        .tolist()
    )
    return latest_files


def transform_iip_ss():
    list_file = [i for i in os.listdir(folder_file)]
    df_all = []
    for file in list_file:
        df0 = pd.read_excel(os.path.join(folder_file, file))
        df = _transform(df0, file)
        df_all.append(df)
    df_all = pd.concat(df_all, ignore_index=True)
    df_all.sort_values(["month"], inplace=True)
    # df_all.to_parquet(os.path.join(DATA_TRANS_PATH, 'iip.parquet'))
    return df_all


def transform_iip_base_2015():
    df_all = []
    for file in get_latest_files_year(folder_file):
        df0 = pd.read_excel(os.path.join(folder_file, file))
        df = _transform_file_base_2015(df0, file)
        df_all.append(df)
    df_all = pd.concat(df_all, ignore_index=True)
    df_all.sort_values(["month"], inplace=True)
    # df_all.to_parquet(os.path.join(DATA_TRANS_PATH, 'iip.parquet'))
    return df_all


def transform_iip():
    logger = get_logger()
    logger.info("_____________Transform IIP______________")
    df_ss = transform_iip_ss()
    df_base = transform_iip_base_2015()
    df_all = df_base.merge(df_ss, how="right", on=["industry", "month"])
    df_all.to_parquet(os.path.join(DATA_TRANS_PATH, "iip.parquet"))
    logger.info("___________DONE transformed IIP______________")
    return df_all


if __name__ == "__main__":
    transform_iip()
