import pandas as pd
import os
import sys
import numpy as np

curr_path = os.path.dirname(os.path.abspath(__file__))
parent_path = curr_path.split("src")[0]
sys.path.append(parent_path)
from src.utils.configs import DATA_INPUT_EURO, DATA_TRANS_PATH
from src.utils.logs import get_logger


logger = get_logger()


def melt_df(data: pd.DataFrame) -> pd.DataFrame:
    """
    Chuyển dạng wide → long cho dữ liệu Euromonitor Company Share.
    """
    id_vars = ["Geography", "Category", "Company Name", "Data Type"]
    return data.melt(id_vars=id_vars, var_name="year", value_name="company_share")


def transform_euromonitor():
    logger.info("____________Transfrom Company_share - Euromonitor__________")
    try:
        df = pd.read_excel(DATA_INPUT_EURO)
        # Xác định header thực tế (dòng đầu tiên có 'Geography' hoặc tương tự)
        header_idx = df[
            df.iloc[:, 0].astype(str).str.contains("Geography", case=False, na=False)
        ].index
        if len(header_idx) > 0:
            header_row = header_idx[0]
        else:
            header_row = 4  # fallback mặc định
        df.columns = df.iloc[header_row, :]
        df = df.drop(index=range(0, header_row + 1))
        df = melt_df(df)
        df["company_share"] = df["company_share"].replace("-", np.nan)
        df["year"] = df["year"].astype(int)
        df["company_share"] = df["company_share"].astype(float)
        df.to_parquet(rf"{DATA_TRANS_PATH}/company_shares.parquet")
        logger.info("__________DONE Transform Company_share Euromonitor__________")
        return df
    except Exception as e:
        logger.error(f"ERROR Tranform Company_share Euromonitor: {e}")


if __name__ == "__main__":
    transform_euromonitor()
