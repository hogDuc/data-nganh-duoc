import pandas as pd
import os
import sys
import re
from datetime import datetime

curr_path = os.path.dirname(os.path.abspath(__file__))
parent_path = curr_path.split("src")[0]
sys.path.append(parent_path)
from src.utils.configs import DATA_RAW_PATH, DATA_TRANS_PATH, DATA_CHART_PATH  # noqa: E402
from src.utils.logs import get_logger  # noqa: E402


logger = get_logger()


def extract_date(name_file):
    """Tìm ngày cập nhật trong tên file."""
    match = re.search(r"(\d{4}-\d{1,2}-\d{1,2})", name_file)
    if match:
        return datetime.strptime(match.group(1), "%Y-%m-%d").strftime("%Y-%m-%d")
    else:
        return "2025-11-01"


def _transform_trademap_prices(time_series):
    """Transform data prices API after downloaded

    Args:
        time_series (str, optional): ['yearly', 'quarterly', 'monthly']

    Returns:
        pd.DataFrame: data cleaned
    """
    # path_file = DATA_RAW_PATH / f"trademap_{time_series}"

    path_file = DATA_RAW_PATH / "trademap"

    list_file = [i for i in os.listdir(path_file) if "prices" in i]

    if time_series in ["yearly", "quarterly", "monthly"]:
        list_file_time = [i for i in list_file if time_series in i]
        df_all = pd.DataFrame()
        for file in list_file_time:
            date_odj = extract_date(file)
            logger.info(f"Processing file: {file}")
            tables = pd.read_html(os.path.join(path_file, file))
            df = tables[-1]  # thường lấy bảng cuối cùng
            df.columns = df.iloc[0, :].tolist()
            df = df.drop(index=[0, 1]).reset_index(drop=True)
            df = df.loc[:, ~df.columns.duplicated()]
            if 'hist' in file:
                df = df.drop(columns=df.columns[-3:])
            else:
                df = df.drop(columns=df.columns[-2:])
            # df.iloc[:, 1:] = df.iloc[:, 1:].astype("float")
            df = df.melt(id_vars="Exporters", var_name="period", value_name="price")
            df["create_date"] = date_odj
            df_all = pd.concat([df_all, df])
        df_all = df_all.drop_duplicates(subset=["Exporters", "period"])
        df_all = df_all.sort_values(["Exporters", "period"]).reset_index(drop=True)
        df_all.to_parquet(rf"{DATA_TRANS_PATH}/trademap_prices_{time_series}.parquet")

    else:
        logger.error("time_series must be in ['yearly', 'quarterly', 'monthly']")
    return df_all


def _transform_trademap_quantities(time_series):
    """Transform data prices API after downloaded

    Args:
        time_series (str, optional): ['yearly', 'quarterly', 'monthly']

    Returns:
        pd.DataFrame: data cleaned
    """
    # path_file = DATA_RAW_PATH / f"trademap_{time_series}"

    path_file = DATA_RAW_PATH / "trademap"

    list_file = [i for i in os.listdir(path_file) if "quantities" in i]
    if time_series in ["yearly", "quarterly", "monthly"]:
        list_file_time = [i for i in list_file if time_series in i]
        df_all = pd.DataFrame()
        for file in list_file_time:
            logger.info(f"Processing file: {file}")
            tables = pd.read_html(os.path.join(path_file, file))
            df = tables[-1]  # thường lấy bảng cuối cùng
            df.columns = df.iloc[0, :].tolist()
            df = df.drop(index=[0, 1]).reset_index(drop=True)
            df = df.loc[:, ~df.columns.duplicated()]
            # df.iloc[:, 1:] = df.iloc[:, 1:].apply(pd.to_numeric, errors="coerce")
            df = df.melt(
                id_vars="Exporters", var_name="period", value_name="quantities"
            )
            if time_series == "yearly":
                df["unit"] = "tons"
            else:
                df["unit"] = "kg"
            df_all = pd.concat([df_all, df])
        df_all = df_all.drop_duplicates(subset=["Exporters", "period"])
        df_all = df_all.sort_values(["Exporters", "period"]).reset_index(drop=True)
        df_all.to_parquet(
            rf"{DATA_TRANS_PATH}/trademap_quatities_{time_series}.parquet"
        )

    else:
        logger.error("time_series must be in ['yearly', 'quarterly', 'monthly']")
    return df_all


def transform_trademap(period):
    logger.info("_________________Transform Trademap_________________")
    if period in ["yearly", "quarterly", "monthly"]:
        _transform_trademap_prices(period)
        _transform_trademap_quantities(period)

    elif period == "all":
        for i in ["yearly", "quarterly", "monthly"]:
            _transform_trademap_prices(i)
            _transform_trademap_quantities(i)
    logger.info("_________________DONE transform Trademap_________________")


def trademap_chart():
    def _merge_data(period):
        logger.info("_________________START chart Trademap_________________")
        api = pd.read_parquet(
            os.path.join(DATA_TRANS_PATH, f"trademap_prices_{period}.parquet")
        ).merge(
            (
                pd.read_parquet(
                    os.path.join(
                        DATA_TRANS_PATH, f"trademap_quatities_{period}.parquet"
                    )
                )
            ),
            on=["Exporters", "period"],
            how="left",
        )

        if period == "monthly":
            # Xóa dòng có giá trị "IMPORTED VALUE..." trong cột period
            api = api[~api["period"].str.contains("Imported value", na=False)]
            api = api[api["period"].str.contains(r'\d{4}-M\d{2}', na=False)]
            api["period"] = api["period"].str.replace("M", "").astype("period[M]")
        # QUARTERLY dạng "2025-Q1"
        elif period == "quarterly":
            api = api[~api["period"].str.contains("Imported value", na=False)]
            api["period"] = api["period"].astype("period[Q]")
        # YEARLY dạng "2025"
        elif period == "yearly":
            api["period"] = api["period"].astype(str)
        else:
            raise
        api.to_parquet(os.path.join(DATA_CHART_PATH, f"trademap_{period}.parquet"))
        api[["period"]].drop_duplicates().sort_values("period").to_parquet(
            os.path.join(DATA_CHART_PATH, f"trademap_{period}_dropdown_period.parquet")
        )
        return api[["Exporters"]].drop_duplicates()

    df_country = pd.DataFrame()
    for period in ["yearly", "quarterly", "monthly"]:
        df0 = _merge_data(period)
        df_country = pd.concat([df_country, df0], ignore_index=True)

    df_country[["Exporters"]].drop_duplicates().sort_values("Exporters").to_parquet(
        os.path.join(DATA_CHART_PATH, "trademap_dropdown_country.parquet")
    )
    logger.info("_________________DONE chart Trademap_________________")

if __name__ == "__main__":
    transform_trademap("all")
    trademap_chart()
    # transform_trademap("quarterly")
    # transform_trademap("monthly")
